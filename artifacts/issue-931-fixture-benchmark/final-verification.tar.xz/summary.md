# Issue #931 PostgreSQL fixture benchmark

Verdict: **GO**

Eligible for adoption: **true**

PostgreSQL 17.12

- `autovacuum` on
- `checkpoint_timeout` 5min
- `fsync` on
- `full_page_writes` on
- `max_connections` 100
- `max_wal_size` 1GB
- `shared_buffers` 128MB
- `synchronous_commit` on
- `wal_level` replica
- `work_mem` 4MB
Median gain: **8.43%**
Median absolute deviation: **2.39%**

| Pair | Fresh seconds | Template seconds | Seconds saved | Gain | Work gain | Flow gain |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 12.169 | 10.520 | 1.650 | 13.56% | 17.17% | 11.39% |
| 2 | 11.510 | 11.341 | 0.169 | 1.47% | -1.65% | 3.06% |
| 3 | 12.251 | 10.925 | 1.325 | 10.82% | 1.12% | 15.33% |
| 4 | 11.527 | 10.577 | 0.949 | 8.24% | -0.20% | 12.59% |
| 5 | 11.508 | 10.539 | 0.970 | 8.43% | 1.37% | 12.09% |

Per-cohort slowdown veto counts: Work 0/5, Flow 0/5.

Raw process evidence and inventory are linked from [index.md](index.md).
