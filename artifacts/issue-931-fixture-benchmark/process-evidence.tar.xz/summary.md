# Issue #931 PostgreSQL fixture benchmark

Verdict: **NO_GO**

Eligible for adoption: **false**

PostgreSQL 17.12

- `autovacuum` on
- `checkpoint_timeout` 5min
- `fsync` on
- `full_page_writes` on
- `max_connections` 100
- `max_wal_size` 1GB
- `shared_buffers` 128MB
- `synchronous_commit` on
- `wal_level` replica
- `work_mem` 4MB
Median gain: **8.16%**
Median absolute deviation: **4.49%**

| Pair | Fresh seconds | Template seconds | Seconds saved | Gain | Work gain | Flow gain |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 11.838 | 10.872 | 0.966 | 8.16% | 1.96% | 11.47% |
| 2 | 11.738 | 11.414 | 0.324 | 2.76% | -4.44% | 6.51% |
| 3 | 11.360 | 10.195 | 1.165 | 10.26% | -3.83% | 17.22% |
| 4 | 12.268 | 10.696 | 1.571 | 12.81% | 0.19% | 18.87% |
| 5 | 12.108 | 11.664 | 0.444 | 3.67% | -0.19% | 5.62% |

Per-cohort slowdown veto counts: Work 0/5, Flow 0/5.

Decision details: median_gain_exceeds_twice_mad.

Raw process evidence and inventory are linked from [index.md](index.md).
