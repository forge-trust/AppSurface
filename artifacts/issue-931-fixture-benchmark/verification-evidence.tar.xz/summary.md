# Issue #931 PostgreSQL fixture benchmark

Verdict: **NO_GO**

Eligible for adoption: **false**

PostgreSQL 17.12

- `autovacuum` on
- `checkpoint_timeout` 5min
- `fsync` on
- `full_page_writes` on
- `max_connections` 100
- `max_wal_size` 1GB
- `shared_buffers` 128MB
- `synchronous_commit` on
- `wal_level` replica
- `work_mem` 4MB
Median gain: **4.90%**
Median absolute deviation: **4.64%**

| Pair | Fresh seconds | Template seconds | Seconds saved | Gain | Work gain | Flow gain |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 11.862 | 11.832 | 0.031 | 0.26% | -6.84% | 3.71% |
| 2 | 11.300 | 10.165 | 1.135 | 10.04% | 5.55% | 12.48% |
| 3 | 11.090 | 10.793 | 0.297 | 2.68% | -0.10% | 4.13% |
| 4 | 12.580 | 11.233 | 1.347 | 10.71% | 3.99% | 14.50% |
| 5 | 11.797 | 11.220 | 0.578 | 4.90% | -1.64% | 8.29% |

Per-cohort slowdown veto counts: Work 1/5, Flow 0/5.

Decision details: median_gain_at_least_5_percent, median_gain_exceeds_twice_mad.

Raw process evidence and inventory are linked from [index.md](index.md).
